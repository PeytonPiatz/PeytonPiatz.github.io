import requests
from datetime import datetime
import smtplib
import time

MY_LAT = 46.911629
MY_LONG = -98.708618


def iss_is_overhead():
    iss_response = requests.get(url="http://api.open-notify.org/iss-now.json")
    iss_response.raise_for_status()
    iss_data = iss_response.json()

    iss_longitude = float(iss_data["iss_position"]["longitude"])
    iss_latitude = float(iss_data["iss_position"]["latitude"])
    lat_distance = MY_LAT - iss_latitude
    long_distance = MY_LONG + iss_longitude
    return 5 >= lat_distance >= -5 or 5 >= long_distance >= -5


parameters = {
    "lng": MY_LONG,
    "lat": MY_LAT,
    "formatted": 0
}

response = requests.get(url="https://api.sunrise-sunset.org/json", params=parameters)
response.raise_for_status()
data = response.json()
sunrise_hour = int(data["results"]["sunrise"].split("T")[1].split(":")[0]) - 6
if sunrise_hour < 0:
    sunrise_hour = 24 + sunrise_hour
sunset_hour = int(data["results"]["sunset"].split("T")[1].split(":")[0]) - 6
if sunset_hour < 0:
    sunset_hour = 24 + sunset_hour

while True:
    time_now = datetime.now()
    current_hour = time_now.hour

    if sunrise_hour <= current_hour or current_hour >= sunset_hour:
        if iss_is_overhead():
            with smtplib.SMTP("outlook.office365.com") as connection:
                connection.starttls()
                connection.login(user="peytonpiatz14@outlook.com", password="Wazzap14")
                connection.sendmail(
                    from_addr="peytonpiatz14@outlook.com",
                    to_addrs="peyton.piatz@kpsd2.us",
                    msg="Subject:ISS Overhead\n\nThe ISS is overhead and it's dark enough to see! Look up!!"
                )
    time.sleep(60)
